<?php 
include("User.php");
$userObj = new User();
$user = $userObj->getUser();
if($user['photo'] == '') {
	$user['photo'] = 'default.jpg';
	$uploadText = "Upload Photo";
} else {
	$uploadText = "Change Photo";
}
include('inc/header.php');
?>
<title>webdamn.com : Demo of Image Upload and Image Crop in Modal with PHP and jQuery</title>
<script src="dist_files/jquery.imgareaselect.js" type="text/javascript"></script>
<script src="dist_files/jquery.form.js"></script>
<link rel="stylesheet" href="dist_files/imgareaselect.css">
<link rel="stylesheet" href="css/style.css">
<script src="js/image_crop_save.js"></script>
<?php include('inc/container.php');?>
<div class="container">
	<h2>Example: Image Upload and Image Crop in Modal with PHP and jQuery</h2>	
	<div class="container emp-profile">		
		<div class="row">
			<div class="col-md-4">
				<div class="profile-img">
					<img id="profilePhoto" data-src="images/<?php echo $user['photo']; ?>"  data-holder-rendered="true" src="images/<?php echo $user['photo']; ?>"/>
					<div class="file btn btn-lg btn-primary" id="changeProfilePhoto">						
					 <?php echo $uploadText; ?>		
					</div>					
				</div>
			</div>				
			<div class="col-md-6">
				<div class="profile-head">
					<h5><?php echo $user['name']; ?></h5>
					<h6><?php echo $user['designation']; ?></h6>					
					<ul class="nav nav-tabs" id="myTab" role="tablist">
						<li class="nav-item">
							<a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
						</li>						
					</ul>
				</div>				
				<div class="col-md-8">
					<div class="tab-content profile-tab" id="myTabContent">
						<div class="show active" id="home" role="tabpanel" aria-labelledby="home-tab">							
							<div class="row">
								<div class="col-md-6">
									<label>Name</label>
								</div>
								<div class="col-md-6">
									<p><?php echo $user['name']; ?></p>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<label>Email</label>
								</div>
								<div class="col-md-6">
									<p><?php echo $user['email']; ?></p>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<label>Phone</label>
								</div>
								<div class="col-md-6">
									<p><?php echo $user['phone']; ?></p>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<label>Profession</label>
								</div>
								<div class="col-md-6">
									<p><?php echo $user['designation']; ?></p>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<label>City</label>
								</div>
								<div class="col-md-6">
									<p><?php echo $user['city']; ?></p>
								</div>
							</div>
							<div class="row">
								<div class="col-md-6">
									<label>Country</label>
								</div>
								<div class="col-md-6">
									<p><?php echo $user['country']; ?></p>
								</div>
							</div>							
						</div>						
					</div>
				</div>			
			</div>			
			<div class="col-md-2">
				<input type="submit" class="profile-edit-btn" name="btnAddMore" value="Edit Profile"/>
			</div>		
		</div>
		<div class="row">
			<div class="col-md-4">
				<div class="profile-work">
					<p>Website</p>
					<a href="<?php echo $user['website']; ?>" rel="nofollow" target="_blank"><?php echo $user['website']; ?></a><br/>					
					<p>Skills</p>					
					<a href=""><?php echo $user['skills']; ?></a><br/>
				</div>
			</div>			
		</div>		
	</div>		
	<div id="changeProfilePhotoModal" class="modal fade">
		<div class="modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				   <h3>Change Profile Photo</h3>
				</div>
				<div class="modal-body">
					<form id="cropImage" method="post" enctype="multipart/form-data" action="change_photo.php">
						<strong>Upload Image:</strong> <br><br>
						<input type="file" name="profileImage" id="profileImage" />
						<input type="hidden" name="hdn-profile-id" id="hdn-profile-id" value="<?php echo $user['id']; ?>" />
						<input type="hidden" name="hdn-x1-axis" id="hdn-x1-axis" value="" />
						<input type="hidden" name="hdn-y1-axis" id="hdn-y1-axis" value="" />
						<input type="hidden" name="hdn-x2-axis" value="" id="hdn-x2-axis" />
						<input type="hidden" name="hdn-y2-axis" value="" id="hdn-y2-axis" />
						<input type="hidden" name="hdn-thumb-width" id="hdn-thumb-width" value="" />
						<input type="hidden" name="hdn-thumb-height" id="hdn-thumb-height" value="" />
						<input type="hidden" name="action" value="" id="action" />
						<input type="hidden" name="imageName" value="" id="imageName" />						
						<div id='previewProfilePhoto'></div>
					<div id="thumbs" style="padding:5px; width:600p"></div>
					</form>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					<button type="button" id="savePhoto" class="btn btn-primary">Crop & Save</button>
				</div>
			</div>
		</div>
	</div>	
</div>
<?php include('inc/footer.php');?>