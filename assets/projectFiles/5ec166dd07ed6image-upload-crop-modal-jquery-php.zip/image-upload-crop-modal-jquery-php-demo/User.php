<?php
class User {
	private $host  = 'localhost';
    private $user  = 'root';
    private $password   = "";
    private $database  = "webdamn_demo";
	private $userTable = 'user_profile';    
	private $dbConnect = false;
    public function __construct(){
        if(!$this->dbConnect){ 
            $conn = new mysqli($this->host, $this->user, $this->password, $this->database);
            if($conn->connect_error){
                die("Error failed to connect to MySQL: " . $conn->connect_error);
            }else{
                $this->dbConnect = $conn;
            }
        }
    }	
	public function getUser() {		
		$sqlQuery = "
			SELECT id, name, email, phone, photo, skills, website, designation, city, country
			FROM ".$this->userTable." 
			WHERE id = 1";		$result = mysqli_query($this->dbConnect, $sqlQuery);		
		$data= mysqli_fetch_array($result, MYSQLI_ASSOC);
		return $data;
	}	
	public function changeProfilePhoto() {
		$post = isset($_POST) ? $_POST: array();
		$maxWidth = "500"; 
		$userId = isset($post['hdn-profile-id']) ? intval($post['hdn-profile-id']) : 0;
		$path = 'images/tmp';
		$validFormats = array("jpg", "png", "gif", "jpeg");
		$picName = $_FILES['profileImage']['name'];
		$size = $_FILES['profileImage']['size'];
		if(strlen($picName)) {
			list($txt, $ext) = explode(".", $picName);
			if(in_array($ext,$validFormats)) {
				if($size<(1024*1024)) {
					$actualImageName = 'avatar' .'_'.$userId .'.'.$ext;
					$filePath = $path .'/'.$actualImageName;
					$tmp = $_FILES['profileImage']['tmp_name'];
					if(move_uploaded_file($tmp, $filePath)) {
						$width = $this->getWidth($filePath);
						$height = $this->getHeight($filePath);						
						if ($width > $maxWidth){
							$scale = $maxWidth/$width;
							$uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
						} else {
							$scale = 1;
							$uploaded = $this->resizeImage($filePath,$width,$height,$scale, $ext);
						}						
						echo "<img id='photo' file-name='".$actualImageName."' class='' src='".$filePath.'?'.time()."' class='preview'/>";
					}
					else
					echo "failed";
				}
				else
				echo "Image file size max 1 MB"; 
			}
			else
			echo "Invalid file format.."; 
		}
		else
		echo "Please select image..!";
		exit;
	}	
	public function saveProfilePhoto() {		
		$post = isset($_POST) ? $_POST: array();
		$userId = isset($post['id']) ? intval($post['id']) : 0;		
		$path = 'images/tmp/'.$_POST['imageName'];
		$tmpWidth = 300; 
		$tmpHeight = 300; 
		if(isset($_POST['t']) and $_POST['t'] == "ajax") {
			extract($_POST);		
			$imagePath = 'images/'.$_POST['imageName'];
			$ratio = ($tmpWidth/$w1); 
			$nw = ceil($w1 * $ratio);
			$nh = ceil($h1 * $ratio);
			$nimg = imagecreatetruecolor($nw,$nh);			
			$imgSrc = imagecreatefromjpeg($path);
			imagecopyresampled($nimg,$imgSrc,0,0,$x1,$y1,$nw,$nh,$w1,$h1);
			imagejpeg($nimg,$imagePath,90);		
		}
		$updateQuery = "
			UPDATE ".$this->userTable." 
			SET photo = '".$_POST['imageName']."'
			WHERE id = '$userId'";
		mysqli_query($this->dbConnect, $updateQuery);
		$saveImagePath = $imagePath.'?'.time();
		echo $saveImagePath;
		exit(0);    
	}    	
	public function resizeImage($image,$width,$height,$scale, $ext) {
		$newImageWidth = ceil($width * $scale);
		$newImageHeight = ceil($height * $scale);
		$newImage = imagecreatetruecolor($newImageWidth,$newImageHeight);
		switch ($ext) {
			case 'jpg':
			case 'jpeg':
				$source = imagecreatefromjpeg($image);
				break;
			case 'gif':
				$source = imagecreatefromgif($image);
				break;
			case 'png':
				$source = imagecreatefrompng($image);
				break;
			default:
				$source = false;
				break;
		}	
		imagecopyresampled($newImage,$source,0,0,0,0,$newImageWidth,$newImageHeight,$width,$height);
		imagejpeg($newImage,$image,90);
		chmod($image, 0777);
		return $image;
	}	
	public function getHeight($image) {
		$sizes = getimagesize($image);
		$height = $sizes[1];
		return $height;
	}	
	public function getWidth($image) {
		$sizes = getimagesize($image);
		$width = $sizes[0];
		return $width;
	}	
}
?>