<?php
include("User.php");
$userObj = new User();
$post = isset($_POST) ? $_POST: array();
switch($post['action']) {
	case 'save' :
	$userObj->saveProfilePhoto();
	break;
	default:
	$userObj->changeProfilePhoto();
}

?>
