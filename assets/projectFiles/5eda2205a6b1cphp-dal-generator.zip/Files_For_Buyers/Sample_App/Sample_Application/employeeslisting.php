<?php
	require_once("./dal/Employee.php");
	
	$firstName = isset($_POST["firstName"]) ? $_POST["firstName"] : NULL;
	$lastName = isset($_POST["lastName"]) ? $_POST["lastName"] : NULL;
	
	$message = NULL;
	$isErrorMessage = false;
	
	if(isset($_POST["deleteRecordId"])) {
		try {
			Employee::delete($_POST["deleteRecordId"]);
			$message = "Record deleted successfully.";
		} catch(Exception $ex) {
			$message = "Unable to delete record.";
			$isErrorMessage = true;
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employees</title>
<link href="style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript">
	function clearFilter() {
		document.getElementById("txtFirstName").value = "";
		document.getElementById("txtLastName").value = "";
		document.getElementById("pageNo").value = '1';
	}
	
	function changePageNo(pageNo) {
		document.getElementById("pageNo").value = pageNo;
	}
	
	function deleteRecord(id) {
		if(!confirm("Are you sure you want to delete this record?")) {
			return;
		}
		
		var deleteRecordId = document.createElement("input");
		deleteRecordId.type = "hidden";
		deleteRecordId.name = "deleteRecordId";
		deleteRecordId.value = id;
		
		var frm = document.getElementById("frm");
		frm.appendChild(deleteRecordId);
		frm.submit();
	}
	
	function changeSort(sortColumn) {
		var sortOrder = "ASC";
		var lastSortColumn = document.getElementById("sortColumn").value;
		
		if (lastSortColumn == sortColumn)
		{
			var lastSortOrder = document.getElementById("sortOrder").value;
			if (lastSortOrder == "ASC")
			{
				sortOrder = "DESC";
			}
		}

		document.getElementById("sortColumn").value = sortColumn;
		document.getElementById("sortOrder").value = sortOrder;
		document.getElementById("pageNo").value = '1';
		document.getElementById("frm").submit();
	}
</script>

</head>

<body>

<div class="page">
	<?php require_once("header.php"); ?>
    <div class="content">
    	<form id="frm" method="post" action="employeeslisting.php">
            <div class="filter">
                <div class="filterHeader">Search</div>
                <table>
                    <tr>
                        <td class="fieldLabel">
                            First Name
                        </td>
                        <td>
                            <input type="text" id="txtFirstName" name="firstName" value="<?php echo $firstName ?>" />
                        </td>
                    </tr>
                    <tr>
                        <td class="fieldLabel">
                            Last Name
                        </td>
                        <td>
                            <input type="text" id="txtLastName" name="lastName" value="<?php echo $lastName ?>" />
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <input type="submit" id="btnSearch" class="button" value="Search" onClick="changePageNo(1);" />
                            <input type="submit" id="btnClear" class="button" value="Clear" onClick="clearFilter();" />
                        </td>
                    </tr>
                </table>
            </div>
        
        	<span id="lblMessage" class="<?php echo ($message != NULL ? ($isErrorMessage ? "errorMessage" : "successMessage") : "") ?>"><?php echo $message ?></span>

            <div>
                <table class="grid">
                	<tr class="gridHeaderRow">
                    	<th><a href="javascript:changeSort('FirstName');">First Name</a></th>
                        <th><a href="javascript:changeSort('LastName');">Last Name</a></th>
                        <th><a href="javascript:changeSort('Gender');">Gender</a></th>
                        <th><a href="javascript:changeSort('EmailAddress');">Email Address</a></th>
                        <th><a href="javascript:changeSort('IsActive');">Active?</a></th>
                        <th class="actionButton"></th>
                        <th class="actionButton"></th>
                    </tr>
                    <?php
						$pageSize = 5;
						$pageNo = isset($_POST["pageNo"]) ? (int)$_POST["pageNo"] : 1;
						$sortOrder = isset($_POST["sortOrder"]) ? $_POST["sortOrder"] : "ASC";
						$sortColumn = isset($_POST["sortColumn"]) ? $_POST["sortColumn"] : "Id";
						$employees = Employee::getAll($pageNo, $pageSize, $totalRecords, $sortColumn, $sortOrder, $firstName, $lastName);
						$totalPages = ceil($totalRecords / $pageSize);
						$previousPageNo = $pageNo > 1 ? ($pageNo - 1) : 1;
						$nextPageNo = $pageNo < $totalPages ? ($pageNo + 1): $totalPages;
						$alternateRow = true;
						
						foreach($employees as $employee) {
							$alternateRow = $alternateRow ? false : true;
                    ?>
                    
                    <tr <?php echo $alternateRow ? "class=\"gridAlternateRow\"" : "" ?>>
                    	<td><?php echo $employee->firstName; ?></td>
                        <td><?php echo $employee->lastName; ?></td>
                        <td><?php echo $employee->gender; ?></td>
                        <td><?php echo $employee->emailAddress; ?></td>
                        <td><?php echo ($employee->isActive ? "Yes" : "No"); ?></td>
                        <td><a title="Edit" href="employeeaddupdate.php?Id=<?php echo $employee->id; ?>"><img title="Edit" src="./images/Edit.png" alt="edit"></a></td>
                        <td><a title="Delete" href="javascript:deleteRecord(<?php echo $employee->id; ?>);"><img title="Delete" src="./images/Delete.png" alt="delete"></a></td>
                    </tr>
                    
                    <?php } ?>
                    <tr>
                    	<td colspan="7">
                        	<?php if($totalPages > 0) { ?>
                                <div class="pager">
                                    <input type="image" id="btnFirst" onClick="changePageNo(1);" title="First" class="pagerButton" src="./images/First.png" />
                                    <input type="image" id="btnPrevious" onClick="changePageNo(<?php echo $previousPageNo ?>);" title="Previous" class="pagerButton" src="./images/Previous.png" />
                                    <span class="pagesCount">Page <?php echo $pageNo ?> of <?php echo $totalPages ?></span>
                                    <input type="image" id="btnNext" onClick="changePageNo(<?php echo $nextPageNo ?>);" title="Next" class="pagerButton" src="./images/Next.png" />
                                    <input type="image" id="btnLast" onClick="changePageNo(<?php echo $totalPages ?>);" title="Last" class="pagerButton" src="./images/Last.png" />
                                </div>
                            <?php
                            	} else {
									echo "No record found";
								}
							?>
                        </td>
                    </tr>
                </table>
            </div>
    
			<a class="button" href="employeeaddupdate.php">Add Employee</a>
            
            <input type="hidden" id="pageNo" name="pageNo" value="<?php echo $pageNo ?>" />
            <input type="hidden" id="sortOrder" name="sortOrder" value="<?php echo $sortOrder ?>" />
            <input type="hidden" id="sortColumn" name="sortColumn" value="<?php echo $sortColumn ?>" />
		</form>
    </div>
</div>

</body>
</html>