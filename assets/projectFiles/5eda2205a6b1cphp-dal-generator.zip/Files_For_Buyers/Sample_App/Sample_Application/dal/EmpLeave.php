<?php
require_once("dbInfo.php");

class EmpLeave {
	public $id;
	public $empId;
	public $leaveTypeId;
	public $dateFrom;
	public $dateTo;

	public function add() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Insert query.
		$sql = "INSERT INTO `empleave`
				(
					`EmpId`,
					`LeaveTypeId`,
					`DateFrom`,
					`DateTo`
				)
				VALUES
				(
					:empId,
					:leaveTypeId,
					STR_TO_DATE(:dateFrom, '%m/%d/%Y'),
					STR_TO_DATE(:dateTo, '%m/%d/%Y')
				);";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":empId" => $this->empId,
			":leaveTypeId" => $this->leaveTypeId,
			":dateFrom" => $this->dateFrom,
			":dateTo" => $this->dateTo));

		// Get value of the auto increment column.
		$newId = $conn->lastInsertId();
		$this->id = $newId;

		// Close the database connection.
		$conn = NULL;

		// Return the id.
		return $newId;
	}

	public function update() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Update query.
		$sql = "UPDATE	`empleave`
				SET		`EmpId` = :empId,
						`LeaveTypeId` = :leaveTypeId,
						`DateFrom` = STR_TO_DATE(:dateFrom, '%m/%d/%Y'),
						`DateTo` = STR_TO_DATE(:dateTo, '%m/%d/%Y')
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":id" => $this->id,
			":empId" => $this->empId,
			":leaveTypeId" => $this->leaveTypeId,
			":dateFrom" => $this->dateFrom,
			":dateTo" => $this->dateTo));

		// Close the database connection.
		$conn = NULL;
	}

	public static function delete($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Delete query.
		$sql = "DELETE	FROM `empleave`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Close the database connection.
		$conn = NULL;
	}

	public static function get($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Select query.
		$sql = "SELECT	`Id`,
						`EmpId`,
						`LeaveTypeId`,
						DATE_FORMAT(`DateFrom`, '%m/%d/%Y') AS DateFrom,
						DATE_FORMAT(`DateTo`, '%m/%d/%Y') AS DateTo
				FROM	`empleave`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Fetch record.
		$empLeave = NULL;
		if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empLeave = new EmpLeave();
			$empLeave->id = $row["Id"];
			$empLeave->empId = $row["EmpId"];
			$empLeave->leaveTypeId = $row["LeaveTypeId"];
			$empLeave->dateFrom = $row["DateFrom"];
			$empLeave->dateTo = $row["DateTo"];
		}

		// Close the database connection.
		$conn = NULL;

		return $empLeave;
	}

	public static function getAll() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);
		$sql = "SELECT	`Id`,
						`EmpId`,
						`LeaveTypeId`,
						DATE_FORMAT(`DateFrom`, '%m/%d/%Y') AS DateFrom,
						DATE_FORMAT(`DateTo`, '%m/%d/%Y') AS DateTo
				FROM	`empleave`;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute();

		// Fetch all records.
		$list = Array();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empLeave = new EmpLeave();
			$empLeave->id = $row["Id"];
			$empLeave->empId = $row["EmpId"];
			$empLeave->leaveTypeId = $row["LeaveTypeId"];
			$empLeave->dateFrom = $row["DateFrom"];
			$empLeave->dateTo = $row["DateTo"];

			array_push($list, $empLeave);
		}

		// Close the database connection.
		$conn = NULL;

		return $list;
	}
}
?>