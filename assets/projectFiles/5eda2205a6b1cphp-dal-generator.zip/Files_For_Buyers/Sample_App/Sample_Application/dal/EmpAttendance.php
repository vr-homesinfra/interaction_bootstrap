<?php
require_once("dbInfo.php");

class EmpAttendance {
	public $id;
	public $date;
	public $empId;

	public function add() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Insert query.
		$sql = "INSERT INTO `empattendance`
				(
					`Date`,
					`EmpId`
				)
				VALUES
				(
					STR_TO_DATE(:date, '%m/%d/%Y'),
					:empId
				);";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":date" => $this->date, ":empId" => $this->empId));

		// Get value of the auto increment column.
		$newId = $conn->lastInsertId();
		$this->id = $newId;

		// Close the database connection.
		$conn = NULL;

		// Return the id.
		return $newId;
	}

	public function update() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Update query.
		$sql = "UPDATE	`empattendance`
				SET		`Date` = STR_TO_DATE(:date, '%m/%d/%Y'),
						`EmpId` = :empId
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":id" => $this->id,
			":date" => $this->date,
			":empId" => $this->empId));

		// Close the database connection.
		$conn = NULL;
	}

	public static function delete($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Delete query.
		$sql = "DELETE	FROM `empattendance`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Close the database connection.
		$conn = NULL;
	}

	public static function get($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Select query.
		$sql = "SELECT	`Id`,
						DATE_FORMAT(`Date`, '%m/%d/%Y') AS Date,
						`EmpId`
				FROM	`empattendance`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Fetch record.
		$empAttendance = NULL;
		if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empAttendance = new EmpAttendance();
			$empAttendance->id = $row["Id"];
			$empAttendance->date = $row["Date"];
			$empAttendance->empId = $row["EmpId"];
		}

		// Close the database connection.
		$conn = NULL;

		return $empAttendance;
	}

	public static function getAll() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);
		$sql = "SELECT	`Id`,
						DATE_FORMAT(`Date`, '%m/%d/%Y') AS Date,
						`EmpId`
				FROM	`empattendance`;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute();

		// Fetch all records.
		$list = Array();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empAttendance = new EmpAttendance();
			$empAttendance->id = $row["Id"];
			$empAttendance->date = $row["Date"];
			$empAttendance->empId = $row["EmpId"];

			array_push($list, $empAttendance);
		}

		// Close the database connection.
		$conn = NULL;

		return $list;
	}
}
?>