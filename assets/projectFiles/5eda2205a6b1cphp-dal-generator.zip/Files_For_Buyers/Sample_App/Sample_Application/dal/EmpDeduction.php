<?php
require_once("dbInfo.php");

class EmpDeduction {
	public $id;
	public $empId;
	public $deductionType;
	public $deductionDate;
	public $amount;

	public function add() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Insert query.
		$sql = "INSERT INTO `empdeduction`
				(
					`EmpId`,
					`DeductionType`,
					`DeductionDate`,
					`Amount`
				)
				VALUES
				(
					:empId,
					:deductionType,
					STR_TO_DATE(:deductionDate, '%m/%d/%Y'),
					:amount
				);";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":empId" => $this->empId,
			":deductionType" => $this->deductionType,
			":deductionDate" => $this->deductionDate,
			":amount" => $this->amount));

		// Get value of the auto increment column.
		$newId = $conn->lastInsertId();
		$this->id = $newId;

		// Close the database connection.
		$conn = NULL;

		// Return the id.
		return $newId;
	}

	public function update() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Update query.
		$sql = "UPDATE	`empdeduction`
				SET		`EmpId` = :empId,
						`DeductionType` = :deductionType,
						`DeductionDate` = STR_TO_DATE(:deductionDate, '%m/%d/%Y'),
						`Amount` = :amount
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":id" => $this->id,
			":empId" => $this->empId,
			":deductionType" => $this->deductionType,
			":deductionDate" => $this->deductionDate,
			":amount" => $this->amount));

		// Close the database connection.
		$conn = NULL;
	}

	public static function delete($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Delete query.
		$sql = "DELETE	FROM `empdeduction`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Close the database connection.
		$conn = NULL;
	}

	public static function get($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Select query.
		$sql = "SELECT	`Id`,
						`EmpId`,
						`DeductionType`,
						DATE_FORMAT(`DeductionDate`, '%m/%d/%Y') AS DeductionDate,
						`Amount`
				FROM	`empdeduction`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Fetch record.
		$empDeduction = NULL;
		if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empDeduction = new EmpDeduction();
			$empDeduction->id = $row["Id"];
			$empDeduction->empId = $row["EmpId"];
			$empDeduction->deductionType = $row["DeductionType"];
			$empDeduction->deductionDate = $row["DeductionDate"];
			$empDeduction->amount = $row["Amount"];
		}

		// Close the database connection.
		$conn = NULL;

		return $empDeduction;
	}

	public static function getAll() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);
		$sql = "SELECT	`Id`,
						`EmpId`,
						`DeductionType`,
						DATE_FORMAT(`DeductionDate`, '%m/%d/%Y') AS DeductionDate,
						`Amount`
				FROM	`empdeduction`;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute();

		// Fetch all records.
		$list = Array();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empDeduction = new EmpDeduction();
			$empDeduction->id = $row["Id"];
			$empDeduction->empId = $row["EmpId"];
			$empDeduction->deductionType = $row["DeductionType"];
			$empDeduction->deductionDate = $row["DeductionDate"];
			$empDeduction->amount = $row["Amount"];

			array_push($list, $empDeduction);
		}

		// Close the database connection.
		$conn = NULL;

		return $list;
	}
}
?>