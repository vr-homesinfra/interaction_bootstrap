<?php
require_once("dbInfo.php");

class EmpSalary {
	public $id;
	public $empId;
	public $month;
	public $year;
	public $amount;

	public function add() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Insert query.
		$sql = "INSERT INTO `empsalary`
				(
					`EmpId`,
					`Month`,
					`Year`,
					`Amount`
				)
				VALUES
				(
					:empId,
					:month,
					:year,
					:amount
				);";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":empId" => $this->empId,
			":month" => $this->month,
			":year" => $this->year,
			":amount" => $this->amount));

		// Get value of the auto increment column.
		$newId = $conn->lastInsertId();
		$this->id = $newId;

		// Close the database connection.
		$conn = NULL;

		// Return the id.
		return $newId;
	}

	public function update() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Update query.
		$sql = "UPDATE	`empsalary`
				SET		`EmpId` = :empId,
						`Month` = :month,
						`Year` = :year,
						`Amount` = :amount
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":id" => $this->id,
			":empId" => $this->empId,
			":month" => $this->month,
			":year" => $this->year,
			":amount" => $this->amount));

		// Close the database connection.
		$conn = NULL;
	}

	public static function delete($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Delete query.
		$sql = "DELETE	FROM `empsalary`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Close the database connection.
		$conn = NULL;
	}

	public static function get($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Select query.
		$sql = "SELECT	`Id`,
						`EmpId`,
						`Month`,
						`Year`,
						`Amount`
				FROM	`empsalary`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Fetch record.
		$empSalary = NULL;
		if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empSalary = new EmpSalary();
			$empSalary->id = $row["Id"];
			$empSalary->empId = $row["EmpId"];
			$empSalary->month = $row["Month"];
			$empSalary->year = $row["Year"];
			$empSalary->amount = $row["Amount"];
		}

		// Close the database connection.
		$conn = NULL;

		return $empSalary;
	}

	public static function getAll() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);
		$sql = "SELECT	`Id`,
						`EmpId`,
						`Month`,
						`Year`,
						`Amount`
				FROM	`empsalary`;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute();

		// Fetch all records.
		$list = Array();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empSalary = new EmpSalary();
			$empSalary->id = $row["Id"];
			$empSalary->empId = $row["EmpId"];
			$empSalary->month = $row["Month"];
			$empSalary->year = $row["Year"];
			$empSalary->amount = $row["Amount"];

			array_push($list, $empSalary);
		}

		// Close the database connection.
		$conn = NULL;

		return $list;
	}
}
?>