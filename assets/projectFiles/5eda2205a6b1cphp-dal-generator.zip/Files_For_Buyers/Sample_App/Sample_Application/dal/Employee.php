<?php
require_once("dbInfo.php");

class Employee {
	public $id;
	public $firstName;
	public $middleName;
	public $lastName;
	public $emailAddress;
	public $isActive;
	public $empTypeId;
	public $designationId;
	public $country;
	public $address;
	public $dateOfBirth;
	public $gender;
	public $passportNo;

	public function add() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Insert query.
		$sql = "INSERT INTO `employee`
				(
					`FirstName`,
					`MiddleName`,
					`LastName`,
					`EmailAddress`,
					`IsActive`,
					`EmpTypeId`,
					`DesignationId`,
					`Country`,
					`Address`,
					`DateOfBirth`,
					`Gender`,
					`PassportNo`
				)
				VALUES
				(
					:firstName,
					:middleName,
					:lastName,
					:emailAddress,
					:isActive,
					:empTypeId,
					:designationId,
					:country,
					:address,
					STR_TO_DATE(:dateOfBirth, '%m/%d/%Y'),
					:gender,
					:passportNo
				);";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":firstName" => $this->firstName,
			":middleName" => $this->middleName,
			":lastName" => $this->lastName,
			":emailAddress" => $this->emailAddress,
			":isActive" => $this->isActive,
			":empTypeId" => $this->empTypeId,
			":designationId" => $this->designationId,
			":country" => $this->country,
			":address" => $this->address,
			":dateOfBirth" => $this->dateOfBirth,
			":gender" => $this->gender,
			":passportNo" => $this->passportNo));

		// Get value of the auto increment column.
		$newId = $conn->lastInsertId();
		$this->id = $newId;

		// Close the database connection.
		$conn = NULL;

		// Return the id.
		return $newId;
	}

	public function update() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Update query.
		$sql = "UPDATE	`employee`
				SET		`FirstName` = :firstName,
						`MiddleName` = :middleName,
						`LastName` = :lastName,
						`EmailAddress` = :emailAddress,
						`IsActive` = :isActive,
						`EmpTypeId` = :empTypeId,
						`DesignationId` = :designationId,
						`Country` = :country,
						`Address` = :address,
						`DateOfBirth` = STR_TO_DATE(:dateOfBirth, '%m/%d/%Y'),
						`Gender` = :gender,
						`PassportNo` = :passportNo
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":id" => $this->id,
			":firstName" => $this->firstName,
			":middleName" => $this->middleName,
			":lastName" => $this->lastName,
			":emailAddress" => $this->emailAddress,
			":isActive" => $this->isActive,
			":empTypeId" => $this->empTypeId,
			":designationId" => $this->designationId,
			":country" => $this->country,
			":address" => $this->address,
			":dateOfBirth" => $this->dateOfBirth,
			":gender" => $this->gender,
			":passportNo" => $this->passportNo));

		// Close the database connection.
		$conn = NULL;
	}

	public static function delete($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Delete query.
		$sql = "DELETE	FROM `employee`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Close the database connection.
		$conn = NULL;
	}

	public static function get($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Select query.
		$sql = "SELECT	`Id`,
						`FirstName`,
						`MiddleName`,
						`LastName`,
						`EmailAddress`,
						`IsActive`,
						`EmpTypeId`,
						`DesignationId`,
						`Country`,
						`Address`,
						DATE_FORMAT(`DateOfBirth`, '%m/%d/%Y') AS DateOfBirth,
						`Gender`,
						`PassportNo`
				FROM	`employee`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Fetch record.
		$employee = NULL;
		if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$employee = new Employee();
			$employee->id = $row["Id"];
			$employee->firstName = $row["FirstName"];
			$employee->middleName = $row["MiddleName"];
			$employee->lastName = $row["LastName"];
			$employee->emailAddress = $row["EmailAddress"];
			$employee->isActive = $row["IsActive"];
			$employee->empTypeId = $row["EmpTypeId"];
			$employee->designationId = $row["DesignationId"];
			$employee->country = $row["Country"];
			$employee->address = $row["Address"];
			$employee->dateOfBirth = $row["DateOfBirth"];
			$employee->gender = $row["Gender"];
			$employee->passportNo = $row["PassportNo"];
		}

		// Close the database connection.
		$conn = NULL;

		return $employee;
	}

	public static function getAll($pageNo, $pageSize, &$totalRecords, $sortColumn, $sortOrder, $firstName, $lastName) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Validate sort column and order.
		$defaultSortColumn = "`Id`";
		$sortColumns = Array("ID", "FIRSTNAME", "LASTNAME", "EMAILADDRESS", "ISACTIVE", "GENDER");
		$sortColumn = in_array(strtoupper($sortColumn), $sortColumns) ? "`$sortColumn`" : $defaultSortColumn;
		$sortOrder = strcasecmp($sortOrder, "DESC") == 0 ? "DESC" : "ASC";

		$parameters = array(":firstName1" => ($firstName != NULL ? "%" . $firstName . "%" : NULL), ":firstName2" => ($firstName != NULL ? "%" . $firstName . "%" : NULL), ":lastName1" => ($lastName != NULL ? "%" . $lastName . "%" : NULL), ":lastName2" => ($lastName != NULL ? "%" . $lastName . "%" : NULL));

		$pageNo = (int)$pageNo;
		$pageSize = (int)$pageSize;

		$sql = "SELECT	COUNT(*) AS Count
				FROM	`employee`
				WHERE	(:firstName1 IS NULL OR `FirstName` LIKE :firstName2)
				AND		(:lastName1 IS NULL OR `LastName` LIKE :lastName2);";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute($parameters);

		// Get total records count.
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		$totalRecords = $row['Count'];
		$stmt = NULL;

		$totalPages = ceil($totalRecords / $pageSize);
		if ($pageNo > $totalPages) {
			$pageNo = $totalPages;
		}

		$start = $pageSize * $pageNo - $pageSize;
		if($start < 0) {
			$start = 0;
		}

		$sql = "SELECT	`Id`,
						`FirstName`,
						`MiddleName`,
						`LastName`,
						`EmailAddress`,
						`IsActive`,
						`EmpTypeId`,
						`DesignationId`,
						`Country`,
						`Address`,
						DATE_FORMAT(`DateOfBirth`, '%m/%d/%Y') AS DateOfBirth,
						`Gender`,
						`PassportNo`
				FROM	`employee`
				WHERE	(:firstName1 IS NULL OR `FirstName` LIKE :firstName2)
				AND		(:lastName1 IS NULL OR `LastName` LIKE :lastName2)
				ORDER BY $sortColumn $sortOrder
				LIMIT $start, $pageSize;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute($parameters);

		// Fetch all records.
		$list = Array();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$employee = new Employee();
			$employee->id = $row["Id"];
			$employee->firstName = $row["FirstName"];
			$employee->middleName = $row["MiddleName"];
			$employee->lastName = $row["LastName"];
			$employee->emailAddress = $row["EmailAddress"];
			$employee->isActive = $row["IsActive"];
			$employee->empTypeId = $row["EmpTypeId"];
			$employee->designationId = $row["DesignationId"];
			$employee->country = $row["Country"];
			$employee->address = $row["Address"];
			$employee->dateOfBirth = $row["DateOfBirth"];
			$employee->gender = $row["Gender"];
			$employee->passportNo = $row["PassportNo"];

			array_push($list, $employee);
		}

		// Close the database connection.
		$conn = NULL;

		return $list;
	}
}
?>