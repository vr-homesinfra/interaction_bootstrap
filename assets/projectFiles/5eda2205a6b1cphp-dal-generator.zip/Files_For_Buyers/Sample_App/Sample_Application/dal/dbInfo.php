<?php
class DatabaseInfo {
	public static function getServer() {
		return "localhost";
	}

	public static function getDatabaseName() {
		return "HRMS";
	}

	public static function getUserName() {
		return "root";
	}

	public static function getPassword() {
		return "";
	}
}
?>