<?php
require_once("dbInfo.php");

class EmpBonus {
	public $id;
	public $empId;
	public $bonusType;
	public $dateApproved;
	public $amount;

	public function add() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Insert query.
		$sql = "INSERT INTO `empbonus`
				(
					`EmpId`,
					`BonusType`,
					`DateApproved`,
					`Amount`
				)
				VALUES
				(
					:empId,
					:bonusType,
					STR_TO_DATE(:dateApproved, '%m/%d/%Y'),
					:amount
				);";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":empId" => $this->empId,
			":bonusType" => $this->bonusType,
			":dateApproved" => $this->dateApproved,
			":amount" => $this->amount));

		// Get value of the auto increment column.
		$newId = $conn->lastInsertId();
		$this->id = $newId;

		// Close the database connection.
		$conn = NULL;

		// Return the id.
		return $newId;
	}

	public function update() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Update query.
		$sql = "UPDATE	`empbonus`
				SET		`EmpId` = :empId,
						`BonusType` = :bonusType,
						`DateApproved` = STR_TO_DATE(:dateApproved, '%m/%d/%Y'),
						`Amount` = :amount
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":id" => $this->id,
			":empId" => $this->empId,
			":bonusType" => $this->bonusType,
			":dateApproved" => $this->dateApproved,
			":amount" => $this->amount));

		// Close the database connection.
		$conn = NULL;
	}

	public static function delete($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Delete query.
		$sql = "DELETE	FROM `empbonus`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Close the database connection.
		$conn = NULL;
	}

	public static function get($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Select query.
		$sql = "SELECT	`Id`,
						`EmpId`,
						`BonusType`,
						DATE_FORMAT(`DateApproved`, '%m/%d/%Y') AS DateApproved,
						`Amount`
				FROM	`empbonus`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Fetch record.
		$empBonus = NULL;
		if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empBonus = new EmpBonus();
			$empBonus->id = $row["Id"];
			$empBonus->empId = $row["EmpId"];
			$empBonus->bonusType = $row["BonusType"];
			$empBonus->dateApproved = $row["DateApproved"];
			$empBonus->amount = $row["Amount"];
		}

		// Close the database connection.
		$conn = NULL;

		return $empBonus;
	}

	public static function getAll() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);
		$sql = "SELECT	`Id`,
						`EmpId`,
						`BonusType`,
						DATE_FORMAT(`DateApproved`, '%m/%d/%Y') AS DateApproved,
						`Amount`
				FROM	`empbonus`;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute();

		// Fetch all records.
		$list = Array();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empBonus = new EmpBonus();
			$empBonus->id = $row["Id"];
			$empBonus->empId = $row["EmpId"];
			$empBonus->bonusType = $row["BonusType"];
			$empBonus->dateApproved = $row["DateApproved"];
			$empBonus->amount = $row["Amount"];

			array_push($list, $empBonus);
		}

		// Close the database connection.
		$conn = NULL;

		return $list;
	}
}
?>