<?php
require_once("dbInfo.php");

class EmpLoan {
	public $id;
	public $empId;
	public $loanDate;
	public $loanTypeId;
	public $amount;

	public function addEmploan() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Insert query.
		$sql = "INSERT INTO `emploan`
				(
					`EmpId`,
					`LoanDate`,
					`LoanTypeId`,
					`Amount`
				)
				VALUES
				(
					:empId,
					STR_TO_DATE(:loanDate, '%m/%d/%Y'),
					:loanTypeId,
					:amount
				);";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":empId" => $this->empId,
			":loanDate" => $this->loanDate,
			":loanTypeId" => $this->loanTypeId,
			":amount" => $this->amount));

		// Get value of the auto increment column.
		$newId = $conn->lastInsertId();
		$this->id = $newId;

		// Close the database connection.
		$conn = NULL;

		// Return the id.
		return $newId;
	}

	public function updateEmploan() {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Update query.
		$sql = "UPDATE	`emploan`
				SET		`EmpId` = :empId,
						`LoanDate` = STR_TO_DATE(:loanDate, '%m/%d/%Y'),
						`LoanTypeId` = :loanTypeId,
						`Amount` = :amount
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(
			":id" => $this->id,
			":empId" => $this->empId,
			":loanDate" => $this->loanDate,
			":loanTypeId" => $this->loanTypeId,
			":amount" => $this->amount));

		// Close the database connection.
		$conn = NULL;
	}

	public static function deleteEmploan($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Delete query.
		$sql = "DELETE	FROM `emploan`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Close the database connection.
		$conn = NULL;
	}

	public static function getEmploan($id) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Select query.
		$sql = "SELECT	`Id`,
						`EmpId`,
						DATE_FORMAT(`LoanDate`, '%m/%d/%Y') AS LoanDate,
						`LoanTypeId`,
						`Amount`
				FROM	`emploan`
				WHERE	`Id` = :id;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute(array(":id" => $id));

		// Fetch record.
		$empLoan = NULL;
		if($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empLoan = new EmpLoan();
			$empLoan->id = $row["Id"];
			$empLoan->empId = $row["EmpId"];
			$empLoan->loanDate = $row["LoanDate"];
			$empLoan->loanTypeId = $row["LoanTypeId"];
			$empLoan->amount = $row["Amount"];
		}

		// Close the database connection.
		$conn = NULL;

		return $empLoan;
	}

	public static function getAllRecords($pageNo, $pageSize, &$totalRecords, $sortColumn, $sortOrder) {
		// Connect to database.
		$options = array(PDO::ATTR_EMULATE_PREPARES => false, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
		$dsn = "mysql:host=" . DatabaseInfo::getServer() . ";dbname=" . DatabaseInfo::getDatabaseName() . ";charset=utf8";
		$conn = new PDO($dsn, DatabaseInfo::getUserName(), DatabaseInfo::getPassword(), $options);

		// Validate sort column and order.
		$defaultSortColumn = "`Id`";
		$sortColumns = Array("ID", "EMPID", "LOANDATE", "LOANTYPEID", "AMOUNT");
		$sortColumn = in_array(strtoupper($sortColumn), $sortColumns) ? "`$sortColumn`" : $defaultSortColumn;
		$sortOrder = strcasecmp($sortOrder, "DESC") == 0 ? "DESC" : "ASC";

		$pageNo = (int)$pageNo;
		$pageSize = (int)$pageSize;

		$sql = "SELECT	COUNT(*) AS Count
				FROM	`emploan`;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute();

		// Get total records count.
		$row = $stmt->fetch(PDO::FETCH_ASSOC);
		$totalRecords = $row['Count'];
		$stmt = NULL;

		$totalPages = ceil($totalRecords / $pageSize);
		if ($pageNo > $totalPages) {
			$pageNo = $totalPages;
		}

		$start = $pageSize * $pageNo - $pageSize;
		if($start < 0) {
			$start = 0;
		}

		$sql = "SELECT	`Id`,
						`EmpId`,
						DATE_FORMAT(`LoanDate`, '%m/%d/%Y') AS LoanDate,
						`LoanTypeId`,
						`Amount`
				FROM	`emploan`
				ORDER BY $sortColumn $sortOrder
				LIMIT $start, $pageSize;";

		// Prepare statement.
		$stmt = $conn->prepare($sql);

		// Execute the statement.
		$stmt->execute();

		// Fetch all records.
		$list = Array();
		while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
			$empLoan = new EmpLoan();
			$empLoan->id = $row["Id"];
			$empLoan->empId = $row["EmpId"];
			$empLoan->loanDate = $row["LoanDate"];
			$empLoan->loanTypeId = $row["LoanTypeId"];
			$empLoan->amount = $row["Amount"];

			array_push($list, $empLoan);
		}

		// Close the database connection.
		$conn = NULL;

		return $list;
	}
}
?>