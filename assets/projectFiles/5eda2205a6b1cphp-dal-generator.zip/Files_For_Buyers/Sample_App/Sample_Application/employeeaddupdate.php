<?php
	require_once("./dal/Employee.php");
	
	$recordId = NULL;
	$queryString = NULL;
	
	if(isset($_GET["Id"])) {
		$recordId = $_GET["Id"];
		$queryString = "?Id=$recordId";
	}
	
	$errorMessages = NULL;
	$employee = NULL;
	$message = NULL;
	$isErrorMessage = false;
	
	if(isset($_POST["recordId"])) {
		try {
			$errorMessages = getErrorMessages();
			if($errorMessages == "") {
				if(isset($_POST["recordId"]) && $_POST["recordId"] != "") {
					$recordId = $_POST["recordId"];
				}
				
				$employee = new Employee();
				$employee->firstName = $_POST["firstName"];
				$employee->middleName = $_POST["middleName"] != "" ? $_POST["middleName"] : NULL;
				$employee->lastName = $_POST["lastName"];
				$employee->emailAddress = $_POST["emailAddress"] != "" ? $_POST["emailAddress"] : NULL;
				$employee->isActive = isset($_POST["isActive"]);
				$employee->empTypeId = $_POST["employeeType"];
				$employee->designationId = $_POST["designation"] != "-1" ? $_POST["designation"] : NULL;
				$employee->country = $_POST["country"] != "-1" ? $_POST["country"] : NULL;
				$employee->address = $_POST["address"] != "" ? $_POST["address"] : NULL;
				$employee->dateOfBirth = $_POST["dateOfBirth"] != "" ? $_POST["dateOfBirth"] : NULL;
				$employee->gender = $_POST["gender"] != "-1" ? $_POST["gender"] : NULL;
				$employee->passportNo = $_POST["passportNo"] != "-1" ? $_POST["passportNo"] : NULL;
				
				if($recordId == NULL) {
					$recordId = $employee->add();
				} else {
					$employee->id = $recordId;
					$employee->update();
				}
				$message = "Record saved successfully.";
			}
		} catch(Exception $ex) {
			$message = "Unable to save record.";
			$isErrorMessage = true;
		}
	} else if($recordId != NULL) {
		try {
			$employee = Employee::get($recordId);
		} catch(Exception $ex) {
			$message = "Unable to get record.";
			$isErrorMessage = true;
		}
	}
	
	function getErrorMessages() {
		$messages = "";
		
		$messages .= $_POST["firstName"] == "" ? "<li>Please enter First Name.</li>" : "";
		$messages .= $_POST["lastName"] == "" ? "<li>Please enter Last Name.</li>" : "";
		$messages .= $_POST["employeeType"] == "-1" ? "<li>Please select Employee Type.</li>" : "";
		
		if($messages != "") {
			$messages = "<ul>$messages</ul>";
		}
		
		return $messages;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Employee Information</title>
<link href="style.css" rel="stylesheet" type="text/css" />

<script type="text/javascript">
	function onSubmit() {
		return true;
	}
</script>

</head>

<body>

<div class="page">
	<?php require_once("header.php"); ?>
    <div class="content">
    	<form id="frm" method="post" action="employeeaddupdate.php<?php echo $queryString; ?>" onSubmit="return onSubmit();">
            <table class="addUpdateForm">
                <tr>
                    <td colspan="2" class="formHeader">
                        Employee Information
                    </td>
                </tr>
                <tr>
                    <td colspan="2">
                        <span id="lblMessage" class="<?php echo ($message != NULL ? ($isErrorMessage ? "errorMessage" : "successMessage") : "") ?>"><?php echo $message ?></span>
                        <span class="errorMessage" style="display: <?php echo ($errorMessages == NULL ? "none;" : "block;"); ?>"><?php echo $errorMessages; ?></span>
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        First Name
                    </td>
                    <td>
                        <input type="text" id="txtFirstName" name="firstName" MaxLength="50" value="<?php if($employee != NULL) echo $employee->firstName ?>" />
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Middle Name
                    </td>
                    <td>
                    	<input type="text" id="txtMiddleName" name="middleName" MaxLength="50" value="<?php if($employee != NULL) echo $employee->middleName ?>" />
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Last Name
                    </td>
                    <td>
                    	<input type="text" id="txtLastName" name="lastName" MaxLength="50" value="<?php if($employee != NULL) echo $employee->lastName ?>" />
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Email Address
                    </td>
                    <td>
                    	<input type="text" id="txtEmailAddress" name="emailAddress" MaxLength="100" value="<?php if($employee != NULL) echo $employee->emailAddress ?>" />
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel"></td>
                    <td>
                    	<input type="checkbox" id="chkIsActive" name="isActive" <?php if($employee != NULL) echo ($employee->isActive ? "checked=\"checked\"" : ""); ?> />
                        <label for="chkIsActive">Active</label>
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Employee Type
                    </td>
                    <td>
                    	<select id="ddlEmployeeType" name="employeeType">
                        	<option value="-1">Select</option>
                            <?php
								require_once("./dal/EmployeeType.php");
								$employeeTypes = EmployeeType::getAll();
								foreach($employeeTypes as $employeeType) {
									$selected = "";
									if($employee != NULL && $employeeType->id == $employee->empTypeId) {
										$selected = " SELECTED";
									}
									echo "<option value=\"$employeeType->id\"$selected>$employeeType->name</option>";
								}
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Designation
                    </td>
                    <td>
                    	<select id="ddlDesignation" name="designation">
                        	<option value="-1">None</option>
                            <?php
								require_once("./dal/Designation.php");
								$designations = Designation::getAll();
								foreach($designations as $designation) {
									$selected = "";
									if($employee != NULL && $designation->id == $employee->designationId) {
										$selected = " SELECTED";
									}
									echo "<option value=\"$designation->id\"$selected>$designation->name</option>";
								}
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Country
                    </td>
                    <td>
                    	<select id="ddlCountry" name="country">
                        	<option value="-1">None</option>
                            <?php
								require_once("./dal/Country.php");
								$countries = Country::getAll();
								foreach($countries as $country) {
									$selected = "";
									if($employee != NULL && $country->id == $employee->country) {
										$selected = " SELECTED";
									}
									echo "<option value=\"$country->id\"$selected>$country->name</option>";
								}
                            ?>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Gender
                    </td>
                    <td>
                    	<?php
							$maleSelected = "";
							$femaleSelected = "";
							
							if($employee != NULL) {
								if($employee->gender == "Male") {
									$maleSelected = " SELECTED";
								} else {
									$femaleSelected = " SELECTED";
								}
							}
                        ?>
                        <select id="ddlGender" name="gender">
                            <option value="-1">None</option>
                            <option value="Male"<?php echo $maleSelected; ?>>Male</option>
                            <option value="Female"<?php echo $femaleSelected; ?>>Female</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Address
                    </td>
                    <td>
                        <input type="text" id="txtAddress" name="address" MaxLength="200" value="<?php if($employee != NULL) echo $employee->address ?>" />
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Date of Birth
                    </td>
                    <td>
                    	<input type="text" id="txtDateOfBirth" name="dateOfBirth" MaxLength="10" value="<?php if($employee != NULL) echo $employee->dateOfBirth ?>" /> (e.g. 03/25/1999)
                    </td>
                </tr>
                <tr>
                    <td class="fieldLabel">
                        Passport No
                    </td>
                    <td>
                    	<input type="text" id="txtPassportNo" name="passportNo" MaxLength="50" value="<?php if($employee != NULL) echo $employee->passportNo ?>" />
                    </td>
                </tr>
                <tr>
                    <td>
                    </td>
                    <td>
                        <input type="submit" id="btnSave" class="button" value="Save" />
                        <input type="button" id="btnCancel" class="button" value="Cancel" onClick="window.location = 'employeeslisting.php'" />
                    </td>
                </tr>
            </table>
            <input type="hidden" name="recordId" value="<?php echo $recordId; ?>" />
		</form>
    </div>
</div>

</body>
</html>