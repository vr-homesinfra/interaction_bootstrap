<div class="header">
    <h1>
        Sample Application
    </h1>
    <div class="navBar">
    	<ul>
        	<li><a href="employeeslisting.php">Employees</a></li>
        </ul>
    </div>
</div>